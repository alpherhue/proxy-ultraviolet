import { Link, useRoute } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { LunarIcon, HomeIcon, GamesIcon, ProxyIcon, SettingsIcon } from "@/lib/icons";

const Header = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const [isHomeActive] = useRoute("/");
  const [isGamesActive] = useRoute("/games");
  const [isProxyActive] = useRoute("/proxy");
  const [isSettingsActive] = useRoute("/settings");

  const NavLink = ({ to, icon, label, isActive }: { to: string; icon: React.ReactNode; label: string; isActive: boolean }) => (
    <Link href={to}>
      <div className={`flex items-center space-x-2 ${isActive ? 'text-primary' : 'text-gray-300 hover:text-primary'} transition duration-150 cursor-pointer`}>
        {icon}
        <span>{label}</span>
      </div>
    </Link>
  );

  return (
    <header className="border-b border-gray-800">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center space-x-2 cursor-pointer">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-700 to-primary flex items-center justify-center">
                <div className="w-8 h-8 rounded-full bg-background flex items-center justify-center">
                  <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-primary to-purple-300"></div>
                </div>
              </div>
              <span className="text-xl font-bold font-poppins text-white">LunarScape</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <NavLink to="/" icon={<HomeIcon className="h-5 w-5" />} label="Home" isActive={isHomeActive} />
            <NavLink to="/games" icon={<GamesIcon className="h-5 w-5" />} label="Games" isActive={isGamesActive} />
            <NavLink to="/proxy" icon={<ProxyIcon className="h-5 w-5" />} label="Proxy" isActive={isProxyActive} />
            <NavLink to="/settings" icon={<SettingsIcon className="h-5 w-5" />} label="Settings" isActive={isSettingsActive} />
          </nav>

          {/* Mobile Menu Button */}
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" className="md:hidden p-0" aria-label="Open Menu">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="bg-background border-r border-gray-800">
              <div className="flex flex-col space-y-6 mt-6">
                <Link href="/">
                  <div className="flex items-center space-x-2 cursor-pointer">
                    <LunarIcon className="h-8 w-8" />
                    <span className="text-xl font-bold">LunarScape</span>
                  </div>
                </Link>
                <nav className="flex flex-col space-y-4">
                  <NavLink to="/" icon={<HomeIcon className="h-5 w-5" />} label="Home" isActive={isHomeActive} />
                  <NavLink to="/games" icon={<GamesIcon className="h-5 w-5" />} label="Games" isActive={isGamesActive} />
                  <NavLink to="/proxy" icon={<ProxyIcon className="h-5 w-5" />} label="Proxy" isActive={isProxyActive} />
                  <NavLink to="/settings" icon={<SettingsIcon className="h-5 w-5" />} label="Settings" isActive={isSettingsActive} />
                </nav>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
};

export default Header;
