import { motion } from "framer-motion";

interface PartnerCardProps {
  id: number;
  name: string;
  logo: string;
  url: string;
}

const PartnerCard = ({ name, logo, url }: PartnerCardProps) => {
  return (
    <motion.a 
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="bg-card rounded-lg p-4 flex items-center justify-center hover:bg-accent transition duration-150"
      whileHover={{ scale: 1.05 }}
      transition={{ duration: 0.2 }}
    >
      <div 
        className="h-16 w-16 object-contain" 
        dangerouslySetInnerHTML={{ __html: logo }}
        title={name}
      />
    </motion.a>
  );
};

export default PartnerCard;
