import { Link } from "wouter";
import { motion } from "framer-motion";
import { SearchIcon } from "@/lib/icons";

const Home = () => {
  return (
    <section className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <motion.h1 
            className="text-4xl md:text-5xl lg:text-6xl font-bold font-poppins mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white via-purple-400 to-primary"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            The Best Place to<br />Evade Internet<br />Censorship.
          </motion.h1>
          
          <motion.p 
            className="text-xl text-gray-300 mb-10"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            200+ games and an ultrafast proxy.
          </motion.p>
          
          <motion.div 
            className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4 justify-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <Link href="/proxy">
              <a className="flex items-center justify-center space-x-2 bg-muted hover:bg-accent text-white py-3 px-6 rounded-lg transition duration-150">
                <SearchIcon className="h-5 w-5" />
                <span>Browse</span>
              </a>
            </Link>
            
            <Link href="/games">
              <a className="flex items-center justify-center space-x-2 bg-gradient-to-r from-purple-700 to-primary hover:opacity-90 text-white py-3 px-6 rounded-lg transition duration-150">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z" />
                </svg>
                <span>Play Games</span>
              </a>
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Home;
