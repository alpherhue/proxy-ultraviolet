// This script will be executed by Vercel during the build process
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

try {
  // Run the build command from package.json
  console.log('Building the application for Vercel...');
  execSync('npm run build', { stdio: 'inherit' });
  
  // Ensure the client files are built properly
  if (!fs.existsSync(path.join(__dirname, 'dist'))) {
    throw new Error('Build failed: dist directory does not exist');
  }
  
  // Create a .vercel directory with project configuration if needed
  if (!fs.existsSync('.vercel')) {
    fs.mkdirSync('.vercel', { recursive: true });
    
    // Create project.json configuration
    const projectConfig = {
      "projectId": "lunarscape",
      "orgId": "lunarscape",
      "settings": {
        "framework": "vite"
      }
    };
    
    fs.writeFileSync('.vercel/project.json', JSON.stringify(projectConfig, null, 2));
  }
  
  console.log('Build completed successfully.');
} catch (error) {
  console.error('Build failed:', error.message);
  process.exit(1);
}