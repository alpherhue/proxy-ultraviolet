import { createProxyMiddleware } from 'http-proxy-middleware';
import { Request, Response, NextFunction } from 'express';

// HTML template for the proxy page with navigation controls
const PROXY_HTML_TEMPLATE = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>LunarScape Web Proxy</title>
  <style>
    :root {
      --primary: #8a2be2;
      --background: #121212;
      --foreground: #e0e0e0;
      --toolbar-height: 44px;
    }
    
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    body {
      background-color: var(--background);
      color: var(--foreground);
      height: 100vh;
      display: flex;
      flex-direction: column;
    }
    
    .toolbar {
      height: var(--toolbar-height);
      background-color: #1e1e1e;
      border-bottom: 1px solid #333;
      display: flex;
      align-items: center;
      padding: 0 10px;
      position: relative;
      z-index: 10;
    }
    
    .toolbar-actions {
      display: flex;
      gap: 8px;
      margin-right: 10px;
    }
    
    .toolbar-btn {
      width: 28px;
      height: 28px;
      border-radius: 4px;
      border: none;
      background-color: #333;
      color: var(--foreground);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: background-color 0.2s;
    }
    
    .toolbar-btn:hover {
      background-color: #444;
    }
    
    .address-bar {
      flex: 1;
      height: 32px;
      background-color: #252525;
      border: 1px solid #444;
      border-radius: 4px;
      color: var(--foreground);
      padding: 0 10px;
      font-size: 14px;
      outline: none;
      transition: border-color 0.2s;
    }
    
    .address-bar:focus {
      border-color: var(--primary);
    }
    
    .home-btn {
      margin-left: 10px;
      padding: 6px 12px;
      background-color: var(--primary);
      color: white;
      border: none;
      border-radius: 4px;
      font-size: 13px;
      cursor: pointer;
      transition: background-color 0.2s;
    }
    
    .home-btn:hover {
      background-color: #7c25d1;
    }
    
    .iframe-container {
      flex: 1;
      position: relative;
    }
    
    .loading-overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: var(--background);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      z-index: 5;
    }
    
    .spinner {
      width: 40px;
      height: 40px;
      border: 4px solid rgba(138, 43, 226, 0.3);
      border-radius: 50%;
      border-top: 4px solid var(--primary);
      animation: spin 1s linear infinite;
      margin-bottom: 20px;
    }
    
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    
    .proxy-frame {
      width: 100%;
      height: 100%;
      border: none;
    }
  </style>
</head>
<body>
  <div class="toolbar">
    <div class="toolbar-actions">
      <button class="toolbar-btn" id="back-btn" title="Go Back">◀</button>
      <button class="toolbar-btn" id="forward-btn" title="Go Forward">▶</button>
      <button class="toolbar-btn" id="refresh-btn" title="Refresh">↻</button>
    </div>
    <input type="text" class="address-bar" id="address-bar" value="{{TARGET_URL}}" readonly>
    <button class="home-btn" id="home-btn">Exit Proxy</button>
  </div>
  
  <div class="iframe-container">
    <div class="loading-overlay" id="loading-overlay">
      <div class="spinner"></div>
      <p>Loading content...</p>
    </div>
    <iframe src="{{PROXY_URL}}" class="proxy-frame" id="proxy-frame"></iframe>
  </div>

  <script>
    // Initialize navigation controls and loading state
    const backBtn = document.getElementById('back-btn');
    const forwardBtn = document.getElementById('forward-btn');
    const refreshBtn = document.getElementById('refresh-btn');
    const homeBtn = document.getElementById('home-btn');
    const addressBar = document.getElementById('address-bar');
    const proxyFrame = document.getElementById('proxy-frame');
    const loadingOverlay = document.getElementById('loading-overlay');
    
    // Handle iframe events
    proxyFrame.addEventListener('load', () => {
      loadingOverlay.style.display = 'none';
      
      try {
        // Try to update address bar with iframe location (may fail due to cross-origin)
        if (proxyFrame.contentWindow && proxyFrame.contentWindow.location.href) {
          addressBar.value = proxyFrame.contentWindow.location.href;
        }
      } catch (e) {
        // Silent fail for cross-origin restriction
      }
    });
    
    // Navigation controls
    backBtn.addEventListener('click', () => {
      proxyFrame.contentWindow.history.back();
      loadingOverlay.style.display = 'flex';
    });
    
    forwardBtn.addEventListener('click', () => {
      proxyFrame.contentWindow.history.forward();
      loadingOverlay.style.display = 'flex';
    });
    
    refreshBtn.addEventListener('click', () => {
      proxyFrame.contentWindow.location.reload();
      loadingOverlay.style.display = 'flex';
    });
    
    homeBtn.addEventListener('click', () => {
      window.location.href = '/';
    });
    
    // Handle iframe navigation errors
    proxyFrame.addEventListener('error', () => {
      loadingOverlay.style.display = 'none';
    });
  </script>
</body>
</html>
`;

/**
 * Creates a proxy server to bypass internet censorship.
 * This implementation uses http-proxy-middleware for proxying requests.
 */
export function createUltravioletProxy() {
  // No bareServer in this implementation
  return {
    /**
     * Serves a proxy page with an iframe that displays the target URL.
     */
    serveProxyPage: (req: Request, res: Response, targetUrl: string) => {
      try {
        // Validate the URL
        const url = new URL(targetUrl);
        const proxyUrl = `/proxy-service/${encodeURIComponent(targetUrl)}`;
        
        // Replace placeholders in the template
        const html = PROXY_HTML_TEMPLATE
          .replace(/{{TARGET_URL}}/g, targetUrl)
          .replace(/{{PROXY_URL}}/g, proxyUrl);
        
        res.setHeader('Content-Type', 'text/html');
        res.send(html);
      } catch (error) {
        console.error("Proxy page error:", error);
        res.status(400).send(`<h1>Invalid URL: ${targetUrl}</h1>`);
      }
    },
    
    /**
     * Creates a proxy middleware for handling direct proxy requests.
     */
    createProxyMiddleware: () => {
      return createProxyMiddleware({
        target: 'https://example.com', // Default target, will be overridden
        changeOrigin: true,
        followRedirects: true,
        secure: false, // Don't validate SSL certificates
        router: (req: any) => {
          try {
            const path = req.originalUrl.replace('/proxy-service/', '');
            const decodedUrl = decodeURIComponent(path);
            
            // Ensure the URL has a protocol
            if (!decodedUrl.startsWith('http://') && !decodedUrl.startsWith('https://')) {
              return 'https://' + decodedUrl;
            }
            
            return decodedUrl;
          } catch (error) {
            console.error('Router error:', error);
            return 'https://example.com';
          }
        },
        pathRewrite: (path) => {
          try {
            // Extract just the path portion from the original URL
            const urlPath = path.replace('/proxy-service/', '');
            const decodedUrl = decodeURIComponent(urlPath);
            
            // Get just the pathname part
            return new URL(decodedUrl).pathname;
          } catch (error) {
            console.error('Path rewrite error:', error);
            return '/';
          }
        },
        // Custom handlers for proxy events
        onProxyReq: (proxyReq: any, req: any, res: any) => {
          // Modify user agent to avoid detection
          proxyReq.setHeader('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36');
          
          // Remove headers that might reveal it's a proxy
          proxyReq.removeHeader('x-forwarded-for');
          proxyReq.removeHeader('x-forwarded-host');
          proxyReq.removeHeader('x-forwarded-proto');
        },
        onProxyRes: (proxyRes: any, req: any, res: any) => {
          // Remove headers that might reveal it's a proxy
          proxyRes.headers['x-frame-options'] = '';
          proxyRes.headers['content-security-policy'] = '';
          
          // Set CORS headers to allow framing
          proxyRes.headers['access-control-allow-origin'] = '*';
          
          // Log success
          console.log(`Proxied: ${req.originalUrl}`);
        },
        onError: (err: Error, req: any, res: any) => {
          console.error('Proxy error:', err);
          
          res.writeHead(500, {
            'Content-Type': 'text/html'
          });
          
          const errorHtml = `
            <html>
              <head>
                <title>Proxy Error</title>
                <style>
                  body {
                    font-family: Arial, sans-serif;
                    padding: 20px;
                    background-color: #121212;
                    color: #e0e0e0;
                  }
                  .error-container {
                    max-width: 600px;
                    margin: 0 auto;
                    background-color: #1e1e1e;
                    padding: 20px;
                    border-radius: 8px;
                    box-shadow: 0 4px 10px rgba(0,0,0,0.2);
                  }
                  h1 {
                    color: #ff5252;
                    margin-top: 0;
                  }
                  .back-btn {
                    margin-top: 20px;
                    background-color: #8a2be2;
                    color: white;
                    border: none;
                    padding: 8px 16px;
                    border-radius: 4px;
                    cursor: pointer;
                  }
                </style>
              </head>
              <body>
                <div class="error-container">
                  <h1>Proxy Error</h1>
                  <p>${err.message}</p>
                  <p>The website you're trying to access couldn't be loaded through the proxy.</p>
                  <button class="back-btn" onclick="window.location.href='/'">Return to Home</button>
                </div>
              </body>
            </html>
          `;
          
          res.end(errorHtml);
        }
      } as any);
    },
    
    /**
     * For compatibility with the rest of the application
     */
    handleBareServer: (_req: Request, _res: Response, next: NextFunction) => {
      next();
    },
    
    /**
     * For compatibility with the rest of the application
     */
    close: () => {
      // Nothing to close
    }
  };
}