# Vercel Deployment Guide for LunarScape

This guide provides detailed instructions for deploying LunarScape to Vercel.

## Preparation

1. **Create a Vercel Account**:
   - Go to [vercel.com](https://vercel.com) and sign up for an account if you don't have one.
   - You can sign up with GitHub, GitLab, or your email.

2. **Install Vercel CLI** (Optional):
   ```bash
   npm install -g vercel
   ```

3. **Prepare Your Repository**:
   - Push your LunarScape code to a Git repository (GitHub, GitLab, or Bitbucket).
   - Ensure all the Vercel configuration files are included:
     - `vercel.json`
     - `vercel-build.js`
     - `api/index.ts`

## Deployment Methods

### Method 1: Using Vercel Dashboard (Recommended for Beginners)

1. **Log in to Vercel Dashboard**:
   - Go to [vercel.com/dashboard](https://vercel.com/dashboard)

2. **Import Your Repository**:
   - Click "Add New" > "Project"
   - Connect to your Git provider (GitHub, GitLab, or Bitbucket)
   - Select your LunarScape repository

3. **Configure Project**:
   - Project Name: Choose a name for your project (e.g., "lunarscape")
   - Framework Preset: Select "Other"
   - Root Directory: Leave as default (/)
   - Build Command: `node vercel-build.js`
   - Output Directory: `dist`

4. **Deploy**:
   - Click "Deploy"
   - Wait for the build to complete

5. **Access Your Site**:
   - Once deployed, you'll receive a URL (e.g., `lunarscape.vercel.app`)
   - Your LunarScape site is now live!

### Method 2: Using Vercel CLI (Advanced)

1. **Log in to Vercel CLI**:
   ```bash
   vercel login
   ```

2. **Navigate to Your Project**:
   ```bash
   cd /path/to/lunarscape
   ```

3. **Deploy the Project**:
   ```bash
   vercel
   ```
   
   During the setup, you'll be asked a few questions:
   - Set up and deploy? Yes
   - Which scope? (Select your account)
   - Link to existing project? No
   - What's your project's name? lunarscape
   - In which directory is your code located? ./
   - Want to override the settings? No

4. **Access Your Site**:
   - Once deployed, you'll receive a URL in the terminal
   - Your LunarScape site is now live!

## Custom Domains

To use a custom domain with your LunarScape deployment:

1. **Go to Vercel Dashboard** > Your Project > Settings > Domains

2. **Add Domain**:
   - Enter your domain name (e.g., `lunarscape.com`)
   - Follow the instructions to configure DNS settings

3. **Verify Domain**:
   - Wait for DNS propagation
   - Vercel will automatically issue and renew SSL certificates

## Troubleshooting

If you encounter any issues during deployment:

1. **Check Build Logs**:
   - Go to Vercel Dashboard > Your Project > Deployments > Latest Deployment > Build Logs
   - Look for error messages that might indicate what went wrong

2. **Common Issues**:
   - **Build Failures**: Check if your code is compatible with Vercel's Node.js version
   - **API Routes Not Working**: Verify your `vercel.json` configuration
   - **Proxy Not Working**: Check the server-side code for compatibility with serverless functions

3. **Vercel Support**:
   - For persistent issues, consult [Vercel Documentation](https://vercel.com/docs)
   - Or contact Vercel support through their dashboard

## Maintenance

To update your deployed application:

1. **Make Changes** to your code locally

2. **Push Changes** to your connected Git repository

3. **Automatic Deployment**:
   - Vercel will automatically detect changes and deploy updates
   - You can view deployment status in your Vercel Dashboard

---

Remember that Vercel offers a free tier with limitations. If you expect high traffic or need additional features, consider upgrading to a paid plan.