import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { createUltravioletProxy } from "./ultraviolet";
import path from "path";
import fs from "fs";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create Ultraviolet proxy handler
  const ultravioletProxy = createUltravioletProxy();

  // Middleware for the bare server (TompHTTP)
  app.use((req, res, next) => {
    ultravioletProxy.handleBareServer(req, res, next);
  });

  // Proxy page that displays websites in an iframe with a toolbar
  app.get('/proxy-page', (req, res) => {
    const url = req.query.url as string;
    
    if (!url) {
      return res.status(400).json({ error: 'URL parameter is required' });
    }

    try {
      // Validate URL
      new URL(url);
      
      // For security, you might want to add additional validation
      // before proxying the request
      
      return ultravioletProxy.serveProxyPage(req, res, url);
    } catch (error) {
      return res.status(400).json({ error: 'Invalid URL' });
    }
  });

  // Legacy proxy route - redirect to new proxy page
  app.get('/api/proxy', (req, res) => {
    const url = req.query.url as string;
    
    if (!url) {
      return res.status(400).json({ error: 'URL parameter is required' });
    }

    // Redirect to the new proxy page
    res.redirect(`/proxy-page?url=${encodeURIComponent(url)}`);
  });

  // Setup the proxy middleware for the actual proxying of websites
  app.use('/proxy-service', ultravioletProxy.createProxyMiddleware());

  // Get quick access sites
  app.get('/api/sites', (req, res) => {
    // In a real application, these would likely come from a database
    // For now, returning a static list
    const sites = [
      { id: 1, name: "Google", url: "https://www.google.com", icon: "google" },
      { id: 2, name: "YouTube", url: "https://www.youtube.com", icon: "youtube" },
      { id: 3, name: "Twitter", url: "https://twitter.com", icon: "twitter" },
      { id: 4, name: "Discord", url: "https://discord.com", icon: "discord" },
      { id: 5, name: "Reddit", url: "https://www.reddit.com", icon: "reddit" },
      { id: 6, name: "Twitch", url: "https://www.twitch.tv", icon: "twitch" },
      { id: 7, name: "Netflix", url: "https://www.netflix.com", icon: "netflix" }
    ];
    
    res.json(sites);
  });

  // Get games list
  app.get('/api/games', (req, res) => {
    // In a real application, these would likely come from a database
    // For now, returning a static list
    const games = [
      { id: 1, name: "Pixel Platformer", image: "/games/pixel-platformer.jpg", categories: ["Platform", "Action"] },
      { id: 2, name: "Space Shooter", image: "/games/space-shooter.jpg", categories: ["Arcade", "Action"] },
      { id: 3, name: "Puzzle Master", image: "/games/puzzle-master.jpg", categories: ["Puzzle", "Strategy"] },
      { id: 4, name: "Racing Extreme", image: "/games/racing-extreme.jpg", categories: ["Racing", "Sports"] },
      { id: 5, name: "Snake Classic", image: "/games/snake-classic.jpg", categories: ["Arcade", "Retro"] }
    ];
    
    res.json(games);
  });

  const httpServer = createServer(app);

  // Clean up function for when the server shuts down
  httpServer.on('close', () => {
    ultravioletProxy.close();
  });

  return httpServer;
}
