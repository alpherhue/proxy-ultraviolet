import type { Request, Response, NextFunction } from "express";
import { createProxyMiddleware } from 'http-proxy-middleware';
import { createBareServer } from '@tomphttp/bare-server-node';
import http, { IncomingMessage, ServerResponse } from 'http';
import fs from 'fs';
import path from 'path';

// HTML template for proxied websites
const PROXY_HTML_TEMPLATE = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>LunarScape Proxy</title>
  <style>
    body, html {
      margin: 0;
      padding: 0;
      height: 100%;
      overflow: hidden;
    }
    .proxy-frame {
      width: 100%;
      height: 100%;
      border: none;
    }
    .proxy-toolbar {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      background: #1a1a2e;
      color: white;
      padding: 8px;
      display: flex;
      align-items: center;
      z-index: 1000;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
    }
    .proxy-url {
      flex-grow: 1;
      margin: 0 10px;
      padding: 5px 10px;
      background: #2d2d3a;
      border: 1px solid #444;
      border-radius: 4px;
      color: white;
    }
    .proxy-btn {
      background: #6a3de8;
      border: none;
      border-radius: 4px;
      color: white;
      padding: 5px 10px;
      cursor: pointer;
      margin-right: 5px;
    }
    .proxy-btn:hover {
      background: #8456ff;
    }
    .proxy-content {
      margin-top: 50px;
      height: calc(100% - 50px);
    }
  </style>
</head>
<body>
  <div class="proxy-toolbar">
    <button class="proxy-btn" onclick="window.location.href='/'">Home</button>
    <input type="text" class="proxy-url" id="url-input" value="{{TARGET_URL}}" />
    <button class="proxy-btn" onclick="navigate()">Go</button>
  </div>
  <div class="proxy-content">
    <iframe src="{{PROXY_URL}}" class="proxy-frame" id="proxy-frame"></iframe>
  </div>
  <script>
    function navigate() {
      const url = document.getElementById('url-input').value;
      window.location.href = '/proxy-page?url=' + encodeURIComponent(url);
    }
    
    document.getElementById('url-input').addEventListener('keydown', function(e) {
      if (e.key === 'Enter') {
        navigate();
      }
    });
  </script>
</body>
</html>
`;

/**
 * Creates a proxy server to bypass internet censorship.
 * This implementation uses http-proxy-middleware for proxying requests.
 */
export function createUltravioletProxy() {
  const bareServer = createBareServer('/bare/');
  
  return {
    /**
     * Serves a proxy page with an iframe that displays the target URL.
     */
    serveProxyPage: (req: Request, res: Response, targetUrl: string) => {
      try {
        // Validate the URL
        const url = new URL(targetUrl);
        const proxyUrl = `/proxy-service/${encodeURIComponent(targetUrl)}`;
        
        // Replace placeholders in the template
        const html = PROXY_HTML_TEMPLATE
          .replace('{{TARGET_URL}}', targetUrl)
          .replace('{{PROXY_URL}}', proxyUrl);
        
        res.setHeader('Content-Type', 'text/html');
        res.send(html);
      } catch (error) {
        console.error("Proxy page error:", error);
        res.status(400).send(`<h1>Invalid URL: ${targetUrl}</h1>`);
      }
    },
    
    /**
     * Creates a proxy middleware for handling direct proxy requests.
     */
    createProxyMiddleware: () => {
      return createProxyMiddleware({
        router: (req: any) => {
          const targetUrl = req.originalUrl.replace('/proxy-service/', '');
          try {
            return decodeURIComponent(targetUrl);
          } catch (e) {
            return targetUrl;
          }
        },
        changeOrigin: true,
        followRedirects: true,
        pathRewrite: (path: string) => {
          const targetUrl = path.replace('/proxy-service/', '');
          try {
            return new URL(decodeURIComponent(targetUrl)).pathname;
          } catch (e) {
            return '/';
          }
        },
        // Custom handlers for proxy events
        onProxyReq(proxyReq: any, req: any, res: any) {
          // Modify user agent to avoid detection
          proxyReq.setHeader('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36');
          
          // Remove headers that might reveal it's a proxy
          proxyReq.removeHeader('x-forwarded-for');
          proxyReq.removeHeader('x-forwarded-host');
          proxyReq.removeHeader('x-forwarded-proto');
        },
        onProxyRes(proxyRes: any, req: any, res: any) {
          // Remove headers that might reveal it's a proxy
          proxyRes.headers['x-frame-options'] = '';
          proxyRes.headers['content-security-policy'] = '';
          
          // Set CORS headers to allow framing
          proxyRes.headers['access-control-allow-origin'] = '*';
        },
        onError(err: Error, req: any, res: any) {
          console.error('Proxy error:', err);
          res.writeHead(500, {
            'Content-Type': 'text/html'
          });
          res.end(`<h1>Proxy Error</h1><p>${err.message}</p>`);
        }
      } as any);
    },
    
    /**
     * Handle the Bare Server requests.
     */
    handleBareServer: (req: Request, res: Response, next: NextFunction) => {
      if (bareServer.shouldRoute(req)) {
        bareServer.routeRequest(req, res);
      } else {
        next();
      }
    },
    
    /**
     * Close the bare server when shutting down.
     */
    close: () => {
      bareServer.close();
    }
  };
}
