import { IncomingMessage, ServerResponse } from 'http';
import { parse } from 'url';
import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import { createUltravioletProxy } from '../server/ultraviolet';
import bodyParser from 'body-parser';

// Create Express app
const app = express();
let appInitialized = false;

// Initialize the Express app with all middleware and routes
function initializeApp() {
  if (appInitialized) return;

  // Basic middlewares
  app.use(cors());
  app.use(bodyParser.json());
  app.use(bodyParser.urlencoded({ extended: true }));

  // Setup proxy
  const ultravioletProxy = createUltravioletProxy();

  // Middleware for the bare server
  app.use((req: Request, res: Response, next: NextFunction) => {
    ultravioletProxy.handleBareServer(req, res, next);
  });

  // Proxy page that displays websites in an iframe with a toolbar
  app.get('/proxy-page', (req: Request, res: Response) => {
    const url = req.query.url as string;
    
    if (!url) {
      return res.status(400).json({ error: 'URL parameter is required' });
    }

    try {
      // Validate URL
      new URL(url);
      return ultravioletProxy.serveProxyPage(req, res, url);
    } catch (error) {
      return res.status(400).json({ error: 'Invalid URL' });
    }
  });

  // Legacy proxy route - redirect to new proxy page
  app.get('/api/proxy', (req: Request, res: Response) => {
    const url = req.query.url as string;
    
    if (!url) {
      return res.status(400).json({ error: 'URL parameter is required' });
    }

    // Redirect to the new proxy page
    res.redirect(`/proxy-page?url=${encodeURIComponent(url)}`);
  });

  // Setup the proxy middleware for the actual proxying of websites
  app.use('/proxy-service', ultravioletProxy.createProxyMiddleware());

  // API endpoints
  app.get('/api/sites', (req: Request, res: Response) => {
    const sites = [
      { id: 1, name: "Google", url: "https://www.google.com", icon: "google" },
      { id: 2, name: "YouTube", url: "https://www.youtube.com", icon: "youtube" },
      { id: 3, name: "Twitter", url: "https://twitter.com", icon: "twitter" },
      { id: 4, name: "Discord", url: "https://discord.com", icon: "discord" },
      { id: 5, name: "Reddit", url: "https://www.reddit.com", icon: "reddit" },
      { id: 6, name: "Twitch", url: "https://www.twitch.tv", icon: "twitch" },
      { id: 7, name: "Netflix", url: "https://www.netflix.com", icon: "netflix" }
    ];
    
    res.json(sites);
  });

  // Get games list
  app.get('/api/games', (req: Request, res: Response) => {
    const games = [
      { id: 1, name: "Pixel Platformer", image: "/games/pixel-platformer.jpg", categories: ["Platform", "Action"] },
      { id: 2, name: "Space Shooter", image: "/games/space-shooter.jpg", categories: ["Arcade", "Action"] },
      { id: 3, name: "Puzzle Master", image: "/games/puzzle-master.jpg", categories: ["Puzzle", "Strategy"] },
      { id: 4, name: "Racing Extreme", image: "/games/racing-extreme.jpg", categories: ["Racing", "Sports"] },
      { id: 5, name: "Snake Classic", image: "/games/snake-classic.jpg", categories: ["Arcade", "Retro"] }
    ];
    
    res.json(games);
  });

  // Health check endpoint
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({ status: 'ok', environment: process.env.NODE_ENV });
  });

  // Error handler
  app.use((err: any, req: Request, res: Response, next: NextFunction) => {
    console.error('API error:', err);
    res.status(500).json({ 
      error: 'An internal server error occurred',
      message: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  });

  appInitialized = true;
}

// Serverless handler for Vercel
export default async function handler(req: IncomingMessage, res: ServerResponse) {
  // Initialize app on first request
  initializeApp();
  
  // Set CORS headers for preflight requests
  if (req.method === 'OPTIONS') {
    res.writeHead(200, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'X-Requested-With, Content-Type, Accept, Authorization',
      'Access-Control-Max-Age': '86400'
    });
    res.end();
    return;
  }

  // Handle the request with Express
  return new Promise((resolve, reject) => {
    // Forward the request to express as any to bypass type checking 
    // This is necessary since we're operating in a serverless context
    // where the standard Express types don't fully apply
    const expressCallback = (err: any) => {
      if (err) {
        reject(err);
        return;
      }
      resolve(undefined);
    };

    // Cast to any to bypass type checking for serverless adapter
    app(req as any, res as any, expressCallback);
  });
}