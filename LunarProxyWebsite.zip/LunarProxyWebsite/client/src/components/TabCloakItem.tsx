import { motion } from "framer-motion";

interface TabCloakItemProps {
  id: number;
  name: string;
  icon: string;
  color: string;
  isActive: boolean;
  onClick: () => void;
}

const TabCloakItem = ({ name, icon, color, isActive, onClick }: TabCloakItemProps) => {
  return (
    <motion.div 
      className={`bg-muted rounded-lg p-3 flex items-center justify-center cursor-pointer hover:bg-accent transition duration-150 ${isActive ? 'ring-2 ring-primary' : ''}`}
      whileHover={{ scale: 1.05 }}
      transition={{ duration: 0.2 }}
      onClick={onClick}
      title={name}
    >
      <div className={`w-10 h-10 rounded-md flex items-center justify-center ${color}`}>
        <div 
          className="h-6 w-6 text-white"
          dangerouslySetInnerHTML={{ __html: icon }}
        />
      </div>
    </motion.div>
  );
};

export default TabCloakItem;
