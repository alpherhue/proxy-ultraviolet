import { AspectRatio } from "@/components/ui/aspect-ratio";
import { useState } from "react";
import { motion } from "framer-motion";

interface GameCardProps {
  id: number;
  name: string;
  image: string;
  categories: string[];
  url: string;
}

const GameCard = ({ id, name, categories, url }: GameCardProps) => {
  const [isHovered, setIsHovered] = useState(false);
  
  const handlePlayGame = () => {
    // This could open the game in a new window or iframe
    window.open(url, "_blank", "noopener,noreferrer");
  };

  return (
    <motion.div 
      className="group cursor-pointer"
      whileHover={{ scale: 1.03 }}
      transition={{ duration: 0.2 }}
      onClick={handlePlayGame}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="bg-gradient-to-br from-purple-800 to-primary p-0.5 rounded-lg shadow-lg">
        <div className="overflow-hidden rounded-t-md">
          <AspectRatio ratio={1 / 1}>
            <div className={`w-full h-full bg-gradient-to-br from-gray-800 to-gray-700 transition duration-200 ${isHovered ? 'scale-105' : 'scale-100'} flex items-center justify-center text-4xl font-bold text-primary/20`}>
              {name.charAt(0)}
            </div>
          </AspectRatio>
        </div>
        <div className="p-3 bg-card rounded-b-md">
          <h3 className="text-sm font-medium text-foreground truncate">{name}</h3>
          <p className="text-xs text-muted-foreground">{categories.join(", ")}</p>
        </div>
      </div>
    </motion.div>
  );
};

export default GameCard;
