import { useState } from "react";
import { SearchIcon, ArrowRightIcon } from "@/lib/icons";
import GameCard from "@/components/GameCard";
import { games } from "@/lib/data";
import { motion } from "framer-motion";
import { Link } from "wouter";

const Games = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [displayedGames, setDisplayedGames] = useState(games.slice(0, 10));

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const term = e.target.value.toLowerCase();
    setSearchTerm(term);
    
    if (term === "") {
      setDisplayedGames(games.slice(0, 10));
    } else {
      const filteredGames = games.filter(
        game => 
          game.name.toLowerCase().includes(term) || 
          game.categories.some(category => category.toLowerCase().includes(term))
      );
      setDisplayedGames(filteredGames);
    }
  };

  return (
    <section className="py-12 bg-background">
      <div className="container mx-auto px-4">
        <motion.div 
          className="flex items-center justify-between mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-bold font-poppins">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-300 to-primary">Featured Games</span>
          </h2>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <SearchIcon className="h-4 w-4 text-gray-400" />
            </div>
            <input 
              type="text" 
              className="block w-full p-2 pl-10 pr-4 rounded-lg bg-muted border border-gray-700 text-foreground placeholder-gray-400 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition duration-150" 
              placeholder="Search Games" 
              value={searchTerm}
              onChange={handleSearch}
            />
          </div>
        </motion.div>

        {/* Game Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
          {displayedGames.map((game, index) => (
            <motion.div
              key={game.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.05 * index }}
            >
              <GameCard {...game} />
            </motion.div>
          ))}
        </div>

        {!searchTerm && games.length > 10 && (
          <motion.div 
            className="text-center mt-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.8 }}
          >
            <Link href="/games/all">
              <a className="inline-flex items-center justify-center space-x-2 bg-muted hover:bg-accent text-foreground py-3 px-6 rounded-lg transition duration-150">
                <span>View All Games</span>
                <ArrowRightIcon className="h-5 w-5" />
              </a>
            </Link>
          </motion.div>
        )}
      </div>
    </section>
  );
};

export default Games;
