import { useState, useEffect } from "react";
import TabCloakItem from "@/components/TabCloakItem";
import { tabIcons } from "@/lib/data";
import { 
  TabCloakSettings, 
  getTabCloakSettings, 
  saveTabCloakSettings, 
  applyTabCloakSettings 
} from "@/lib/tabCloak";
import { usePanicKey } from "@/hooks/usePanicKey";
import { motion } from "framer-motion";

const Settings = () => {
  const [tabCloakSettings, setTabCloakSettings] = useState<TabCloakSettings>(getTabCloakSettings());
  const [isAdvancedCloakingEnabled, setIsAdvancedCloakingEnabled] = useState(false);
  const { keyCombo, redirectUrl, setKeyCombo, setRedirectUrl } = usePanicKey();

  useEffect(() => {
    applyTabCloakSettings(tabCloakSettings);
  }, [tabCloakSettings]);

  const handleTabIconClick = (iconId: number) => {
    const newSettings = { ...tabCloakSettings, iconId };
    setTabCloakSettings(newSettings);
    saveTabCloakSettings(newSettings);
  };

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newSettings = { ...tabCloakSettings, title: e.target.value };
    setTabCloakSettings(newSettings);
    saveTabCloakSettings(newSettings);
  };

  const handleIconUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newSettings = { ...tabCloakSettings, favicon: e.target.value };
    setTabCloakSettings(newSettings);
    saveTabCloakSettings(newSettings);
  };

  const enableAdvancedCloaking = () => {
    setIsAdvancedCloakingEnabled(true);
    // This would typically open the site in an about:blank page
    const win = window.open("about:blank", "_blank");
    if (win) {
      win.document.write(`
        <html>
          <head>
            <title>${tabCloakSettings.title}</title>
            <link rel="icon" href="${tabCloakSettings.favicon}" type="image/x-icon">
          </head>
          <body>
            <iframe src="${window.location.origin}" style="position:fixed; top:0; left:0; bottom:0; right:0; width:100%; height:100%; border:none; margin:0; padding:0; overflow:hidden; z-index:999999;"></iframe>
          </body>
        </html>
      `);
    }
  };

  const disableAdvancedCloaking = () => {
    setIsAdvancedCloakingEnabled(false);
    // No real action needed here, as disabling just means not using the about:blank method
  };

  const handlePanicKeyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setKeyCombo(e.target.value);
  };

  const handleRedirectUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setRedirectUrl(e.target.value);
  };

  return (
    <section className="py-12 bg-gradient-to-b from-muted to-background">
      <div className="container mx-auto px-4">
        <motion.h2 
          className="text-3xl font-bold font-poppins mb-8 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-300 to-primary">Privacy Settings</span>
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* Tab Cloaking */}
          <motion.div 
            className="bg-card rounded-lg p-6"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h3 className="text-xl font-semibold mb-4">Tab Cloak</h3>
            <div className="grid grid-cols-5 gap-4 mb-4">
              {tabIcons.map((icon) => (
                <TabCloakItem
                  key={icon.id}
                  {...icon}
                  isActive={tabCloakSettings.iconId === icon.id}
                  onClick={() => handleTabIconClick(icon.id)}
                />
              ))}
            </div>
            <p className="text-muted-foreground text-sm mb-4">This will automatically be saved across our site!</p>
            
            {/* Title and Icon Controls */}
            <div className="mb-4">
              <label className="block text-foreground text-sm font-medium mb-2">Custom Tab Title</label>
              <input 
                type="text" 
                className="block w-full p-2 rounded-lg bg-muted border border-gray-700 text-foreground placeholder-gray-400 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition duration-150" 
                placeholder="Google Drive" 
                value={tabCloakSettings.title}
                onChange={handleTitleChange}
              />
            </div>
            
            <div>
              <label className="block text-foreground text-sm font-medium mb-2">Custom Tab Icon URL</label>
              <input 
                type="text" 
                className="block w-full p-2 rounded-lg bg-muted border border-gray-700 text-foreground placeholder-gray-400 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition duration-150" 
                placeholder="https://example.com/favicon.ico" 
                value={tabCloakSettings.favicon}
                onChange={handleIconUrlChange}
              />
            </div>
          </motion.div>
          
          {/* Advanced Cloaking */}
          <motion.div 
            className="bg-card rounded-lg p-6"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <h3 className="text-xl font-semibold mb-4">Advanced about:blank Cloaking</h3>
            <p className="text-foreground mb-4">This will hide our site from your history!</p>
            <p className="text-yellow-400 mb-4">You need to enable popups for this to work.</p>
            
            <div className="flex space-x-4">
              <button 
                className={`${isAdvancedCloakingEnabled ? 'bg-primary' : 'bg-primary hover:bg-primary/80'} text-white py-2 px-4 rounded-lg transition duration-150`}
                onClick={enableAdvancedCloaking}
              >
                Enable
              </button>
              <button 
                className={`${!isAdvancedCloakingEnabled ? 'bg-muted' : 'bg-muted hover:bg-accent'} text-foreground py-2 px-4 rounded-lg transition duration-150`}
                onClick={disableAdvancedCloaking}
              >
                Disable
              </button>
            </div>
            
            <div className="mt-8">
              <h3 className="text-xl font-semibold mb-4">Panic Key</h3>
              <p className="text-foreground mb-2">Quickly exit the site when in danger.</p>
              
              <div className="bg-muted p-3 rounded-lg">
                <p className="text-sm text-muted-foreground mb-2">Key will appear here...</p>
                <div className="flex flex-wrap gap-2">
                  <div className="bg-accent text-foreground py-1 px-3 text-sm rounded">
                    <span>{keyCombo}</span>
                  </div>
                  <div className="flex items-center">
                    <input
                      type="text"
                      className="bg-muted border border-gray-700 text-foreground placeholder-gray-400 py-1 px-3 text-sm rounded mr-2 focus:outline-none focus:border-primary"
                      placeholder="Alt+P"
                      value={keyCombo}
                      onChange={handlePanicKeyChange}
                    />
                  </div>
                </div>
              </div>
              
              <div className="mt-4">
                <label className="block text-foreground text-sm font-medium mb-2">Redirect URL</label>
                <input 
                  type="text" 
                  className="block w-full p-2 rounded-lg bg-muted border border-gray-700 text-foreground placeholder-gray-400 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition duration-150" 
                  placeholder="https://classroom.google.com" 
                  value={redirectUrl}
                  onChange={handleRedirectUrlChange}
                />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Settings;
