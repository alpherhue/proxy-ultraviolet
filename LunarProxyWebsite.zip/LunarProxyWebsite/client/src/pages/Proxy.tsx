import { useState, KeyboardEvent } from "react";
import { SearchIcon } from "@/lib/icons";
import QuickAccessCard from "@/components/QuickAccessCard";
import { quickAccessSites } from "@/lib/data";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

const Proxy = () => {
  const [searchValue, setSearchValue] = useState("");
  const { toast } = useToast();

  const handleSearch = () => {
    if (!searchValue) {
      toast({
        title: "Search field is empty",
        description: "Please enter a URL or search query",
        variant: "destructive",
      });
      return;
    }

    // Check if the input is a valid URL
    let url = searchValue;
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      // If not a URL, treat as a Google search
      if (!url.includes('.')) {
        url = `https://www.google.com/search?q=${encodeURIComponent(url)}`;
      } else {
        url = `https://${url}`;
      }
    }

    // Navigate to the proxy page with the URL as a parameter
    window.open(`/proxy-page?url=${encodeURIComponent(url)}`, '_blank');
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <section className="py-12 bg-gradient-to-b from-background to-muted">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <motion.h2 
            className="text-3xl font-bold font-poppins mb-8 text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-300 to-primary">Access Any Website</span>
          </motion.h2>

          {/* Search Bar */}
          <motion.div 
            className="relative mb-12 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <SearchIcon className="h-5 w-5 text-gray-400" />
            </div>
            <input 
              type="text" 
              className="block w-full p-4 pl-10 pr-4 rounded-lg bg-background border border-gray-700 text-foreground placeholder-gray-400 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition duration-150" 
              placeholder="Search Google or type a URL" 
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              onKeyDown={handleKeyDown}
            />
          </motion.div>

          {/* Quick Access Sites */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
            {quickAccessSites.map((site, index) => (
              <motion.div
                key={site.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.1 * index }}
              >
                <QuickAccessCard {...site} />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Proxy;
