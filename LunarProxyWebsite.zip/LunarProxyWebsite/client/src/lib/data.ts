export const quickAccessSites = [
  {
    id: 1,
    name: "Google",
    url: "https://www.google.com",
    iconSvg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M21.35 11.1h-9.17v2.73h6.51c-.33 3.81-3.5 5.44-6.5 5.44C8.36 19.27 5 16.25 5 12c0-4.1 3.2-7.27 7.2-7.27 3.09 0 4.9 1.97 4.9 1.97L19 4.72S16.56 2 12.1 2C6.42 2 2.03 6.8 2.03 12c0 5.05 4.13 10 10.22 10 5.35 0 9.25-3.67 9.25-9.09 0-1.15-.15-1.81-.15-1.81Z"/></svg>`,
    color: "#4285F4"
  },
  {
    id: 2,
    name: "YouTube",
    url: "https://www.youtube.com",
    iconSvg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M23.5 6.2c-.3-1-1-1.8-2-2-1.8-.5-9-.5-9-.5s-7.2 0-9 .5c-1 .3-1.7 1-2 2-.5 1.8-.5 5.8-.5 5.8s0 4 .5 5.8c.3 1 1 1.8 2 2 1.8.5 9 .5 9 .5s7.2 0 9-.5c1-.3 1.7-1 2-2 .5-1.8.5-5.8.5-5.8s0-4-.5-5.8Z"/><path fill="#fff" d="M9.5 15.2V8.8l6 3.2-6 3.2Z"/></svg>`,
    color: "#FF0000"
  },
  {
    id: 3,
    name: "Twitter",
    url: "https://twitter.com",
    iconSvg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M23.643 4.937c-.835.37-1.732.62-2.675.733.962-.576 1.7-1.49 2.048-2.578-.9.534-1.897.922-2.958 1.13-.85-.904-2.06-1.47-3.4-1.47-2.572 0-4.658 2.086-4.658 4.66 0 .364.042.718.12 1.06-3.873-.195-7.304-2.05-9.602-4.868-.4.69-.63 1.49-.63 2.342 0 1.616.823 3.043 2.072 3.878-.764-.025-1.482-.234-2.11-.583v.06c0 2.257 1.605 4.14 3.737 4.568-.392.106-.803.162-1.227.162-.3 0-.593-.028-.877-.082.593 1.85 2.313 3.198 4.352 3.234-1.595 1.25-3.604 1.995-5.786 1.995-.376 0-.747-.022-1.112-.065 2.062 1.323 4.51 2.093 7.14 2.093 8.57 0 13.255-7.098 13.255-13.254 0-.2-.005-.402-.014-.602.91-.658 1.7-1.477 2.323-2.41z"/></svg>`,
    color: "#1DA1F2"
  },
  {
    id: 4,
    name: "Discord",
    url: "https://discord.com",
    iconSvg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189Z"/></svg>`,
    color: "#5865F2"
  },
  {
    id: 5,
    name: "Reddit",
    url: "https://www.reddit.com",
    iconSvg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10zm2.598-15.5a1.5 1.5 0 11.804 2.899A1.5 1.5 0 0114.598 6.5zm-1.598 8.594c.607 0 3.499-.498 3.499-2.5 0-2.001-1.39-4.594-3.499-4.594s-3.499 2.593-3.499 4.594c0 2.002 2.892 2.5 3.499 2.5zm-4.099-6.195a1.5 1.5 0 11-.804-2.899 1.5 1.5 0 01.804 2.899z"/><path d="M12.174 16.085c.389 0 .884-.158 1.345-.456.05-.042.09-.149.022-.214l-.409-.392c-.062-.059-.144-.023-.193.016-.341.279-.694.443-1.01.443-.316 0-.669-.164-1.01-.443-.05-.039-.131-.075-.193-.016l-.409.392c-.068.065-.028.172.022.214.461.298.956.456 1.345.456zm-3.928-5.086c0-.563.457-1.02 1.02-1.02.562 0 1.02.457 1.02 1.02 0 .563-.458 1.02-1.02 1.02s-1.02-.457-1.02-1.02zm5.304 1.02c-.562 0-1.02-.457-1.02-1.02 0-.563.458-1.02 1.02-1.02.562 0 1.02.457 1.02 1.02 0 .563-.458 1.02-1.02 1.02z"/></svg>`,
    color: "#FF4500"
  },
  {
    id: 6,
    name: "Twitch",
    url: "https://www.twitch.tv",
    iconSvg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M11.571 4.714h1.715v5.143H11.57zm4.715 0H18v5.143h-1.714zM6 0L1.714 4.286v15.428h5.143V24l4.286-4.286h3.428L22.286 12V0zm14.571 11.143l-3.428 3.428h-3.429l-3 3v-3H6.857V1.714h13.714z"/></svg>`,
    color: "#9146FF"
  },
  {
    id: 7,
    name: "Netflix",
    url: "https://www.netflix.com",
    iconSvg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M5.398 0v24l6.5-1.568V0h-6.5zm13.304 0l-6.5 1.568v20.864l6.5 1.568V0z"/></svg>`,
    color: "#E50914"
  }
];

export const games = [
  {
    id: 1,
    name: "Pixel Platformer",
    image: "/assets/pixel-platformer.jpg",
    categories: ["Platform", "Action"],
    url: "/games/pixel-platformer"
  },
  {
    id: 2,
    name: "Space Shooter",
    image: "/assets/space-shooter.jpg",
    categories: ["Arcade", "Action"],
    url: "/games/space-shooter"
  },
  {
    id: 3,
    name: "Puzzle Master",
    image: "/assets/puzzle-master.jpg",
    categories: ["Puzzle", "Strategy"],
    url: "/games/puzzle-master"
  },
  {
    id: 4,
    name: "Racing Extreme",
    image: "/assets/racing-extreme.jpg",
    categories: ["Racing", "Sports"],
    url: "/games/racing-extreme"
  },
  {
    id: 5,
    name: "Snake Classic",
    image: "/assets/snake-classic.jpg",
    categories: ["Arcade", "Retro"],
    url: "/games/snake-classic"
  },
  {
    id: 6,
    name: "2048",
    image: "/assets/2048.jpg",
    categories: ["Puzzle", "Strategy"],
    url: "/games/2048"
  },
  {
    id: 7,
    name: "Flappy Bird",
    image: "/assets/flappy-bird.jpg",
    categories: ["Arcade", "Challenge"],
    url: "/games/flappy-bird"
  },
  {
    id: 8,
    name: "Tetris",
    image: "/assets/tetris.jpg",
    categories: ["Puzzle", "Classic"],
    url: "/games/tetris"
  },
  {
    id: 9,
    name: "Minesweeper",
    image: "/assets/minesweeper.jpg",
    categories: ["Puzzle", "Classic"],
    url: "/games/minesweeper"
  },
  {
    id: 10,
    name: "Asteroids",
    image: "/assets/asteroids.jpg",
    categories: ["Arcade", "Shooter"],
    url: "/games/asteroids"
  }
];

export const partners = [
  {
    id: 1,
    name: "TGC Gaming",
    logo: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 36 36"><circle cx="18" cy="18" r="18" fill="#333"/><text x="5" y="23" fill="white" font-family="Arial" font-weight="bold" font-size="12">TGC</text></svg>`,
    url: "https://example.com/tgc"
  },
  {
    id: 2,
    name: "Cat Gaming",
    logo: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 36 36"><circle cx="18" cy="18" r="18" fill="#FFDD00"/><path d="M12 12c0 1.1 0.9 2 2 2s2 -0.9 2 -2 -0.9 -2 -2 -2 -2 0.9 -2 2zm10 0c0 1.1 0.9 2 2 2s2 -0.9 2 -2 -0.9 -2 -2 -2 -2 0.9 -2 2z" fill="#222"/><path d="M18 25c-3.3 0 -6 -2.7 -6 -6v-2h12v2c0 3.3 -2.7 6 -6 6z" fill="white" stroke="#222" stroke-width="1"/></svg>`,
    url: "https://example.com/cat-gaming"
  },
  {
    id: 3,
    name: "PixelLab",
    logo: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 36 36"><rect width="36" height="36" rx="4" fill="#8B5CF6"/><text x="7" y="23" fill="white" font-family="Arial" font-weight="bold" font-size="14">S</text></svg>`,
    url: "https://example.com/pixellab"
  },
  {
    id: 4,
    name: "GameFlask",
    logo: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 36 36"><rect width="36" height="36" rx="4" fill="#FF00FF"/><path d="M18 10v16M13 14h10M13 22h10" stroke="white" stroke-width="2"/></svg>`,
    url: "https://example.com/gameflask"
  },
  {
    id: 5,
    name: "Bigfoot's Game Shack",
    logo: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 36 36"><circle cx="18" cy="18" r="18" fill="#8B4513"/><path d="M13 13h10v10h-10z" fill="#D2B48C"/></svg>`,
    url: "https://example.com/bigfoot"
  },
  {
    id: 6,
    name: "Moon Gaming",
    logo: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 36 36"><circle cx="18" cy="18" r="18" fill="#000033"/><circle cx="18" cy="18" r="12" fill="#CCCCFF"/><circle cx="14" cy="15" r="2" fill="#000033"/><circle cx="22" cy="15" r="2" fill="#000033"/></svg>`,
    url: "https://example.com/moon-gaming"
  },
  {
    id: 7,
    name: "Vercel",
    logo: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 36 36"><polygon points="18,8 28,28 8,28" fill="#8B5CF6"/></svg>`,
    url: "https://vercel.com"
  }
];

export const tabIcons = [
  {
    id: 1,
    name: "Lunar",
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M11 3a1 1 0 10-2 0v1a1 1 0 102 0V3zM15.657 5.757a1 1 0 00-1.414-1.414l-.707.707a1 1 0 001.414 1.414l.707-.707zM18 10a1 1 0 01-1 1h-1a1 1 0 110-2h1a1 1 0 011 1zM5.05 6.464A1 1 0 106.464 5.05l-.707-.707a1 1 0 00-1.414 1.414l.707.707zM5 10a1 1 0 01-1 1H3a1 1 0 110-2h1a1 1 0 011 1zM8 16v-1h4v1a2 2 0 11-4 0zM12 14c.015-.34.208-.646.477-.859a4 4 0 10-4.954 0c.27.213.462.519.476.859h4.002z" /></svg>`,
    color: "bg-gradient-to-br from-purple-700 to-primary"
  },
  {
    id: 2,
    name: "Document",
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M7 3a1 1 0 000 2h6a1 1 0 100-2H7zM4 7a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1zM2 11a2 2 0 012-2h12a2 2 0 012 2v4a2 2 0 01-2 2H4a2 2 0 01-2-2v-4z" /></svg>`,
    color: "bg-red-500"
  },
  {
    id: 3,
    name: "School",
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M10.394 2.08a1 1 0 00-.788 0l-7 3a1 1 0 000 1.84L5.25 8.051a.999.999 0 01.356-.257l4-1.714a1 1 0 11.788 1.838L7.667 9.088l1.94.831a1 1 0 00.787 0l7-3a1 1 0 000-1.838l-7-3zM3.31 9.397L5 10.12v4.102a8.969 8.969 0 00-1.05-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762zM9.3 16.573A9.026 9.026 0 007 14.935v-3.957l1.818.78a3 3 0 002.364 0l5.508-2.361a11.026 11.026 0 01.25 3.762 1 1 0 01-.89.89 8.968 8.968 0 00-5.35 2.524 1 1 0 01-1.4 0zM6 18a1 1 0 001-1v-2.065a8.935 8.935 0 00-2-.712V17a1 1 0 001 1z" /></svg>`,
    color: "bg-green-500"
  },
  {
    id: 4,
    name: "Code",
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M12.316 3.051a1 1 0 01.633 1.265l-4 12a1 1 0 11-1.898-.632l4-12a1 1 0 011.265-.633zM5.707 6.293a1 1 0 010 1.414L3.414 10l2.293 2.293a1 1 0 11-1.414 1.414l-3-3a1 1 0 010-1.414l3-3a1 1 0 011.414 0zm8.586 0a1 1 0 011.414 0l3 3a1 1 0 010 1.414l-3 3a1 1 0 11-1.414-1.414L16.586 10l-2.293-2.293a1 1 0 010-1.414z" clip-rule="evenodd" /></svg>`,
    color: "bg-blue-500"
  },
  {
    id: 5,
    name: "Download",
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M6 2a2 2 0 00-2 2v12a2 2 0 002 2h8a2 2 0 002-2V7.414A2 2 0 0015.414 6L12 2.586A2 2 0 0010.586 2H6zm5 6a1 1 0 10-2 0v3.586l-1.293-1.293a1 1 0 10-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 00-1.414-1.414L11 11.586V8z" clip-rule="evenodd" /></svg>`,
    color: "bg-purple-500"
  }
];
