export type TabCloakSettings = {
  title: string;
  favicon: string;
  iconId: number | null;
};

const defaultSettings: TabCloakSettings = {
  title: "LunarScape",
  favicon: "/favicon.ico",
  iconId: null
};

// Function to set the page title
export const setPageTitle = (title: string): void => {
  document.title = title;
};

// Function to set the page favicon
export const setFavicon = (iconUrl: string): void => {
  const link = document.querySelector("link[rel='icon']") || document.createElement("link");
  link.setAttribute("rel", "icon");
  link.setAttribute("type", "image/x-icon");
  link.setAttribute("href", iconUrl);
  
  if (!document.querySelector("link[rel='icon']")) {
    document.head.appendChild(link);
  }
};

// Function to save the tab cloak settings in localStorage
export const saveTabCloakSettings = (settings: TabCloakSettings): void => {
  localStorage.setItem("lunarscape_tab_cloak", JSON.stringify(settings));
};

// Function to get the tab cloak settings from localStorage
export const getTabCloakSettings = (): TabCloakSettings => {
  const savedSettings = localStorage.getItem("lunarscape_tab_cloak");
  return savedSettings ? JSON.parse(savedSettings) : defaultSettings;
};

// Function to apply the tab cloak settings
export const applyTabCloakSettings = (settings: TabCloakSettings = getTabCloakSettings()): void => {
  setPageTitle(settings.title);
  setFavicon(settings.favicon);
};

// Function to reset the tab cloak settings to default
export const resetTabCloakSettings = (): void => {
  saveTabCloakSettings(defaultSettings);
  applyTabCloakSettings(defaultSettings);
};

// Initialize tab cloaking on page load
export const initTabCloak = (): void => {
  const settings = getTabCloakSettings();
  applyTabCloakSettings(settings);
};
