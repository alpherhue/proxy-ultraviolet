import { useEffect, useState } from "react";
import { useLocalStorage } from "./useLocalStorage";

interface PanicKeyConfig {
  keyCombo: string;
  redirectUrl: string;
}

const defaultConfig: PanicKeyConfig = {
  keyCombo: "Alt+P",
  redirectUrl: "https://classroom.google.com"
};

export function usePanicKey() {
  const [config, setConfig] = useLocalStorage<PanicKeyConfig>("lunarscape_panic_key", defaultConfig);
  const [isListening, setIsListening] = useState(true);

  const handleKeyDown = (e: KeyboardEvent) => {
    if (!isListening) return;

    const keys = config.keyCombo.split("+");
    const modifierKey = keys[0].toLowerCase();
    const letterKey = keys[1]?.toLowerCase();

    const isModifierPressed =
      (modifierKey === "alt" && e.altKey) ||
      (modifierKey === "ctrl" && e.ctrlKey) ||
      (modifierKey === "shift" && e.shiftKey);

    const isLetterPressed = e.key.toLowerCase() === letterKey?.toLowerCase();

    if (isModifierPressed && isLetterPressed) {
      e.preventDefault();
      window.location.href = config.redirectUrl || defaultConfig.redirectUrl;
    }
  };

  useEffect(() => {
    if (isListening) {
      window.addEventListener("keydown", handleKeyDown);
    }

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [isListening, config]);

  const setKeyCombo = (keyCombo: string) => {
    setConfig({ ...config, keyCombo });
  };

  const setRedirectUrl = (redirectUrl: string) => {
    setConfig({ ...config, redirectUrl });
  };

  const toggleListening = () => {
    setIsListening(!isListening);
  };

  return {
    keyCombo: config.keyCombo,
    redirectUrl: config.redirectUrl,
    isListening,
    setKeyCombo,
    setRedirectUrl,
    toggleListening
  };
}
