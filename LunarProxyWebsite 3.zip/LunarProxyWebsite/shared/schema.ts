import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const tabCloaks = pgTable("tab_cloaks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  title: text("title").notNull(),
  iconUrl: text("icon_url"),
  isActive: boolean("is_active").default(false),
});

export const panicKeys = pgTable("panic_keys", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  keyCombo: text("key_combo").notNull(),
  redirectUrl: text("redirect_url").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertTabCloakSchema = createInsertSchema(tabCloaks).pick({
  userId: true,
  title: true,
  iconUrl: true,
  isActive: true,
});

export const insertPanicKeySchema = createInsertSchema(panicKeys).pick({
  userId: true,
  keyCombo: true,
  redirectUrl: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertTabCloak = z.infer<typeof insertTabCloakSchema>;
export type TabCloak = typeof tabCloaks.$inferSelect;

export type InsertPanicKey = z.infer<typeof insertPanicKeySchema>;
export type PanicKey = typeof panicKeys.$inferSelect;
