// Type definitions for Vercel serverless function

import { IncomingMessage, ServerResponse } from 'http';

declare namespace NodeJS {
  interface ProcessEnv {
    NODE_ENV: 'development' | 'production' | 'test';
    VERCEL?: string;
    VERCEL_URL?: string;
  }
}

export interface VercelRequest extends IncomingMessage {
  query: {
    [key: string]: string | string[];
  };
  cookies: {
    [key: string]: string;
  };
  body: any;
}

export interface VercelResponse extends ServerResponse {
  status(statusCode: number): VercelResponse;
  send(body: any): VercelResponse;
  json(jsonBody: any): VercelResponse;
}

export type VercelApiHandler = (
  req: VercelRequest,
  res: VercelResponse
) => void | Promise<void>;