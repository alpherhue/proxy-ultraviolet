import { LunarIcon, GlobeIcon, ChatIcon, InfoIcon } from "@/lib/icons";

const Footer = () => {
  return (
    <footer className="py-8 bg-background border-t border-gray-800">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="flex items-center space-x-2 mb-4 md:mb-0">
            <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-700 to-primary flex items-center justify-center">
              <div className="w-6 h-6 rounded-full bg-background flex items-center justify-center">
                <div className="w-4 h-4 rounded-full bg-gradient-to-tr from-primary to-purple-300"></div>
              </div>
            </div>
            <span className="text-lg font-bold font-poppins text-white">LunarScape</span>
          </div>
          
          <div className="text-center mb-4 md:mb-0">
            <p className="text-gray-400 text-sm">Made by Wilbert Sirleaf</p>
          </div>
          
          <div className="flex space-x-4">
            <a href="#" className="text-gray-400 hover:text-white transition duration-150">
              <GlobeIcon className="h-5 w-5" />
            </a>
            <a href="#" className="text-gray-400 hover:text-white transition duration-150">
              <ChatIcon className="h-5 w-5" />
            </a>
            <a href="#" className="text-gray-400 hover:text-white transition duration-150">
              <InfoIcon className="h-5 w-5" />
            </a>
          </div>
        </div>
        
        <div className="mt-6 text-center">
          <p className="text-gray-500 text-xs">© 2023-2024 LunarScape. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
