import { motion } from "framer-motion";

interface QuickAccessCardProps {
  id: number;
  name: string;
  url: string;
  iconSvg: string;
  color: string;
}

const QuickAccessCard = ({ name, url, iconSvg, color }: QuickAccessCardProps) => {
  const handleClick = () => {
    // Use the proxy page to navigate to the site - using current window 
    window.location.href = `/proxy-page?url=${encodeURIComponent(url)}`;
  };

  return (
    <motion.div 
      className="bg-card rounded-lg p-4 flex flex-col items-center justify-center hover:bg-accent transition duration-150 cursor-pointer"
      whileHover={{ scale: 1.05 }}
      transition={{ duration: 0.2 }}
      onClick={handleClick}
    >
      <div className="w-12 h-12 mb-2 flex items-center justify-center">
        <div 
          className="w-8 h-8 text-white"
          style={{ color }}
          dangerouslySetInnerHTML={{ __html: iconSvg }}
        />
      </div>
      <span className="text-sm text-center text-foreground">{name}</span>
    </motion.div>
  );
};

export default QuickAccessCard;
